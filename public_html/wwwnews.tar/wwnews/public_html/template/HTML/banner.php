<table width="600" cellspacing="0" cellpadding="0" border="0" class="contenttbl">
	<tbody>
		<tr>
			<td align="center" style="border-collapse: collapse; padding: 20px 0pt 10px; text-align: center;" class="cheader txtcenter">
				<a href="###LINK1###" style="text-decoration:none;">
					<img border="0" src="###SRC###" alt="###ALT###" />
				</a>
			</td>
		</tr>
	</tbody>
</table>
<table border="0">
	<tr>
		<td valign="middle" height="10"></td>
	</tr>
</table>

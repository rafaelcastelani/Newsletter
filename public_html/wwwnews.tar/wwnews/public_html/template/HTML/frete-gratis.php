
<table width="600" cellspacing="0" cellpadding="0" border="0" class="contenttbl">
	<tbody>
		<tr>
			<td align="center" style="border-collapse: collapse; padding: 20px 0pt 10px; text-align: center;" class="cheader txtcenter"><img
				src="http://n.westwing.com.br/images/4370/I-4370-qnhbiqakrx-banner_news_frete_gratis.jpg" alt="" />
			</td>
		</tr>
	</tbody>
</table>
<table bgcolor="#FFFFFF" width="600" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td align="center"><img alt="Westing Wine Day" src="http://n.bamarang.com.br/images/4477/I-4370-lcbnhrvpda-wine-day.jpg" /></td>
	</tr>
</table>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-BR" lang="pt-BR">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Westwing Newsletter</title>
</head>
<body style="width: 100%; margin: 0; padding: 0; -webkit-text-size-adjust: none;">

	<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#ffffff"
		style="font-size: 13px; font-family: Arial, Helvetica, sans-serif; text-align: left; line-height: 16px;">
		<tr>
			<td align="center">
				<table width="600" cellspacing="0" cellpadding="0" style="border: 1px solid #ecebdc;">
					<tr>
						<td align="center">
							<table width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#ecebdc">
								<tr>
									<td valign="middle" height="25" bgcolor="#ecebdc" align="center"><font face="Arial, Helvetica, sans-serif"
										style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #807e73; line-height: 13px;"> Adicione o endereço de email <a target="_blank"
											style="text-decoration: underline; color: rgb(128, 126, 115); border: medium none; font-weight: normal;" href="mailto:newsletter@n.westwing.com.br ">newsletter@n.westwing.com.br</a> ao seu catálogo de endereços. | <a href="##Online_Mailing_HTML##"
											style="text-decoration: underline; color: rgb(128, 126, 115); border: medium none; font-weight: normal;">Webview</a>
									</font></td>
								</tr>
							</table>
							<table width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff">
								<tr>
									<td width="600" valign="top" height="90" align="left"><a target="_blank"
										style="font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #ffffff; text-decoration: none;"
										href="http://www.westwing.com.br/?nl=BR.NL.UMS.20111202CN.99000.99&wt_cc4=IMG&wt_cc2=1"> <font face="Arial, Helvetica, sans-serif"
											style="font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #ffffff"> <strong> <font face="Times New Roman, Times, serif"
													style="font-family: 'Times New Roman', Times, serif; font-size: 14px; color: #807e73;"> <img width="600" height="90" border="0"
														alt="Westwing Casa & Decoração" style="display: block;"
														src="http://n.westwing.com.br/images/4370/M-4370-3218695-M_4291_3192019_M_4291_3192019_M_4291_3192019_header_BR_mod.jpg" />
												</font>
											</strong>
										</font>
									</a></td>
								</tr>
								<tr>
									<td width="600" height="4" align="center" valign="top"><img width="600" height="4" style="display: block" alt=""
										src="http://n.westwing.de/imgproxy/img/609893372/trenner.jpg" /></td>
								</tr>
							</table>
							<table border="0">
								<tr>
									<td valign="middle" height="10"></td>
								</tr>
							</table>
							<table width="600" cellspacing="0" cellpadding="0" border="0" class="contenttbl">
								<tbody>
									<tr>
										<td align="center" class="cheader txtcenter" style="border-collapse: collapse; padding: 20px 0pt 10px; text-align: center;">
											<a style="text-decoration:none;" href="http://www.westwing.com.br/best-sellers/?email=##Field_email##&amp;utm_source=sale-newsletter&amp;utm_medium=ww-newsletter&amp;utm_campaign=sale-nl-20120421">
												<img border="0" alt="Best Sellers - Best Sellers" src="http://n.westwing.com.br/images/4370/I-4370-vkxeqkpfpw-best-sellers-banner.jpg">
											</a>
										</td>
									</tr>
								</tbody>
							</table>

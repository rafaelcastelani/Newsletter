							<table>
								<tr>
									<td>&nbsp;</td>
								</tr>
							</table>
							<table width="600" cellspacing="0" cellpadding="0" border="0">
								<tr>
									<td align="center" valign="top">
										<table width="580" cellspacing="0" cellpadding="0" border="0">
											<tr>
												<td width="580" valign="top" align="center">
													<a target="_blank" title="Visite-nos no Facebook!" style="text-decoration: none;" href="http://www.facebook.com/WestWingBR">
														<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; font-weight: bold; color: #807e73;">
															<img width="580" height="99" border="0" style="display: block;" alt="Visite-nos no Facebook!" src="http://n.westwing.com.br/images/4370/I-4370-uwfstxypon-facebook-newsletter-30-11-11.jpg" />
														</font>
													</a>
												</td>
											</tr>
											<tr>
												<td width="580" height="14" valign="top"></td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<!-- end banner fb  -->
							<!-- footer -->
							<table width="600" cellspacing="0" cellpadding="0" border="0">
								<tr>
									<td width="600" height="4" align="center" valign="top"><img
										width="600" height="4" style="display: block" alt=""
										src="http://n.westwing.de/imgproxy/img/609893372/trenner.jpg" />
									</td>
								</tr>
							</table>
							<table width="600" cellspacing="12" cellpadding="0" border="0" style="border-bottom:1px solid #ECEBDC;margin-bottom:1px;">
								<tr>
									<td align="center" valign="top">
										<p style="margin:0 0 5px 0;">
											<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #807e73; line-height: 12px;">&copy; Westwing Casa &amp; Decoração - Todos os Direitos Reservados</font>
										</p>
										<p style="margin: 10px 0;">
											<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #807e73; line-height: 12px;">SAC - telefone: 0800-940-0328 ou e-mail: atendimento@westwing.com.br</font>
										</p>
										<p style="margin: 10px 0;">
											<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #807e73; line-height: 12px;">De segunda a sexta-feira, das 8h às 20h. Sábado, das 9h às 15h</font>
										</p>
										<p style="margin: 10px 0;">
											<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #807e73; line-height: 12px;">Para alterar suas opções de recebimento de newsletters <br/>acesse a opção "<a style="text-decoration: underline; color: rgb(128, 126, 115); border: medium none; font-weight: normal;"  target="_blank" href="https://www.westwing.com.br/customer/newsletter/manage">Gerenciar Newsletter</a>" dentro do menu "Minha Conta"</font>
										</p>
										<p style="margin:5px 0 0 0;">
											<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #807e73; line-height: 12px;">* Quando seu amigo convidado fizer a primeira compra você receberá um voucher de R$ 20,00 com validade de 180 dias. Quando se cadastrar, o seu amigo convidado também receberá um voucher de R$ 20,00 com validade de 30 dias. Os vouchers somente poderão ser utilizados para compras com valores superiores a R$ 120,00.</font>
										</p>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
<table width="580" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<!-- ESQUERDA -->
		<td align="center">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<!-- titulo -->
					<td align="center" valign="middle" height="40">
						<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 16px; color: #807e73; text-transform: uppercase;">Próximas</font>
						<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; color: #807e73; text-transform: uppercase;">campanhas</font>
					</td>
				</tr>
			</table>
			<table width="100%" cellspacing="0" cellpadding="0" border="0" style="border: 2px dotted #DDDCCF;">
				<tr>
					<td align="center">
						<table width="250" cellspacing="0" cellpadding="0" border="0">
							<tr>
								<!-- imagem -->
								<td>
									<table width="250" cellspacing="12" cellpadding="0" border="0">
										<tr>
											<td align="center" valign="top">
												<a target="_blank" title="###TITLE###" style="text-decoration: none;" href="###LINK1###">
													<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; font-weight: bold; color: #807e73;">
														<img width="250" height="218" border="0" style="display: block;" alt="###ALT###" src="###SRC###" />
													</font>
												</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<!-- texto -->
								<td align="center">
									<table width="250" cellspacing="0" cellpadding="0" border="0">
										<tr>
											<td valign="top" align="left">
												<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 20px; color: #807e73; text-transform: uppercase; line-height: 20px;">
												###NOMELOJA###
												</font> <br />
												<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; color: #807e73; text-transform: uppercase; line-height: 20px;">
												###DESCRICAO###
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							###ALTURA###
							<tr>
								<td align="center">
									<table width="250" cellspacing="0" cellpadding="0" border="0">
										<tr>
											<td valign="top" align="center">
												<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 16px; color: #807e73; font-style: italic; line-height: 20px;">
												###INICIOTERMINO### 
												<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-style: normal;">###DATA###</font>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>

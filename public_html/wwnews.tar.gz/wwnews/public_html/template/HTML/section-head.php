<table width="600" cellspacing="0" cellpadding="0" border="0"
	class="contenttbl">
	<tbody>
		<tr>
			<td align="center" style="border-collapse: collapse; padding: 20px 0pt 10px; text-align: center;" class="cheader txtcenter">
				<font style="line-height: 120%; color: rgb(128, 126, 115); font-size: 16px; margin: 0pt; font-family: 'Times New Roman', Times, serif; text-transform: uppercase;" class="fs16 ffs ucase">
					###SECTION-MAIN-NAME### 
					<span style="color: rgb(128, 126, 115); font-size: 15px; margin: 0pt; font-family: 'Arial', 'Helvetica', Sans-serif;" class="ffss fs15">
						###SECTION-SECOND-NAME###
					</span>
				</font>
			</td>
		</tr>
	</tbody>
</table>


		<td valign="top" align="center" style="border: 2px dotted #DDDCCF;">
			<table width="250" cellspacing="12" cellpadding="0" border="0">
				<tr>
					<td valign="top">
						<a target="_blank" title="###TITLE###" style="text-decoration: none;" href="###LINK1###">
							<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; font-weight: bold; color: #807e73;">
								<img width="250" height="218" border="0" style="display: block;" alt="###ALT###" src="###SRC###" />
							</font>
						</a>
					</td>
				</tr>
				<tr>
					<td valign="top" align="left">
						<table width="250" cellspacing="0" cellpadding="0" border="0">
							<tr>
								<td colspan="2" align="left" valign="top">
									<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 20px; color: #807e73; text-transform: uppercase; line-height: 20px;">
										###NOMELOJA###
									</font><br />
									<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; color: #807e73; text-transform: uppercase; line-height: 20px;">
										###DESCRICAO###
									</font>
								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
							</tr>
							<tr>
								<td align="left" valign="bottom" width="120">
									<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 16px; color: #807e73; font-style: italic; line-height: 16px;text-transform: uppercase;">
										###INICIOTERMINO### 
										<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-style: normal;">
											###DATA###
										</font>
									</font><br />
									<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times; font-size: 16px; color: #807e73; font-style: italic; line-height: 20px;text-transform: uppercase;">
									###AS### 
										<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-style: normal;">
											###HORA###
										</font>
									</font>
								</td>
							
								<td align="right" valign="bottom">
									<a target="_blank" style="font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #ffffff; text-decoration: none;" href="###LINK2###">
										<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 18px; color: #ffffff">
											<strong>
												<img width="125" border="0" alt="Compre Agora" style="display: block;" src="http://n.westwing.com.br/images/4370/M-4370-3218695-botao_comprar_peq.jpg" />
											</strong>
										</font>
									</a>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	

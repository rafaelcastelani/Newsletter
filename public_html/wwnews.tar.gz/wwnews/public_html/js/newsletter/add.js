$(document).ready(function(){
	$('#nl_submit_date').datetimepicker({	showSecond: true,
											dateFormat: 'yy-mm-dd',
											timeFormat: 'hh:mm:ss'});
});
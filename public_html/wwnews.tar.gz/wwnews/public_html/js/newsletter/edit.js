$(document).ready(function() {
	/*
	$.ajax({
		url: "/newsletter/generateblock/type/1",
		success: function(data){
			$("#header").after(data)
		}
	});
	*/
	
});





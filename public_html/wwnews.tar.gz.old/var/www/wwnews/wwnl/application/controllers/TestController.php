<?php
require 'BaseController.php';
class TestController extends BaseController {
	
	public function indexAction(){
		$this->_helper->viewRenderer->setNoRender();
		
		
	}

}
?>
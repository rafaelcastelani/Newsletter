		<td width="7">&nbsp;</td>
		<td align="center">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<!-- titulo -->
					<td align="center" valign="middle" height="40">
						<table>
							<tr>
								<td>
									<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 16px; color: #807e73; text-transform: uppercase;">
										Novidades na
									</font>
								</td>
								<td>
									<img alt="Magazin" height="27" src="http://n.westwing.com.br/images/4370/M-4370-3218695-apcedjmgzq_revista.jpg" style="height: auto; line-height: 100%; outline: medium none; text-decoration: none; display: block; border: 0pt none;" width="82" />
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #EBEAD9;">
				<tr>
					<td align="center">
						<table width="250" cellspacing="0" cellpadding="0" border="0">
							<tr>
								<!-- imagem -->
								<td>
									<table width="250" cellspacing="12" cellpadding="0" border="0">
										<tr>
											<td align="center" valign="top">
												<a target="_blank" title="Veja as dicas!" style="text-decoration: none;" href="###LINK1###">
													<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; font-weight: bold; color: #807e73;">
														<img width="250" height="218" border="0" style="display: block;" alt="Confira a matéria da revista!" src="###SRC###" />
													</font>
												</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<!-- texto -->
								<td align="center">
									<table width="250" cellspacing="0" cellpadding="0" border="0">
										<tr>
											<td valign="top" align="left">
												<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 20px; color: #807e73; text-transform: uppercase; line-height: 20px;">
												###NOMELOJA### 
												</font><br />
												<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; color: #807e73; text-transform: uppercase; line-height: 20px;">
													<font style="color: #807e73;">&nbsp;</font>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							###ALTURA###
							<tr>
								<td align="center">
									<table width="250" cellspacing="0" cellpadding="0" border="0">
										<tr>
											<td valign="top" align="left">
												<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 15px; color: #807e73; line-height: 20px;">###DESCRICAO###</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td align="center">
									<table width="250" cellspacing="12" cellpadding="0" border="0">
										<tr>
											<td valign="top" align="right" height="28">
												<font face="Times New Roman, Times, serif" style="font-family: 'Times New Roman', Times, serif; font-size: 16px; font-style: italic; color: #807e73; line-height: 20px; text-transform: uppercase;">
													<a target="_blank" style="color: #807e73; text-decoration: underline; font-size: 16px; font-style: italic; text-transform: uppercase;" href="###LINK2###">
														Acesse o site
													</a>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

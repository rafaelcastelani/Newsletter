<!-- banner invite  -->
<table width="600" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td align="center" valign="top">
			<table width="600" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<td width="600" valign="top" align="center">
						<a target="_blank" title="Convide seus amigos!" style="text-decoration: none;" href="http://www.westwing.com.br/customer/invitation/create/?nl=BR.NL.UMS.20111202CN.99001.99&wt_cc4=IMG&wt_cc2=###COUNT###">
							<font face="Arial, Helvetica, sans-serif" style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; font-weight: bold; color: #807e73;">
								<img width="600" height="109" border="0" style="display: block;" alt="Convide seus amigos!" src="http://n.westwing.com.br/images/4370/M-4370-3218695-invite_teaser_BR_mod.jpg" />
							</font>
						</a>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<!-- end banner invite -->